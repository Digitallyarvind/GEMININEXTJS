import { Service, BlogPost } from '../types';
import React from 'react';

// FIX: Re-wrote icon components and their usage with React.createElement to avoid using JSX in a .ts file.
// This resolves a series of errors related to unrecognized JSX syntax.
const WebDevIcon = () => React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-10 w-10 text-primary", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: 2 }, React.createElement('path', { strokeLinecap: "round", strokeLinejoin: "round", d: "M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" }));
const SeoIcon = () => React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-10 w-10 text-primary", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: 2 }, React.createElement('path', { strokeLinecap: "round", strokeLinejoin: "round", d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" }));
const CmsIcon = () => React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-10 w-10 text-primary", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: 2 }, React.createElement('path', { strokeLinecap: "round", strokeLinejoin: "round", d: "M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4M4 7l8 5 8-5" }));


const mockServices: Service[] = [
  {
    id: 1,
    title: 'Static Site Generation (SSG)',
    description: 'Blazing fast, pre-rendered static HTML pages for content that doesn\'t change on every request. Ideal for SEO and user experience.',
    icon: React.createElement(WebDevIcon),
  },
  {
    id: 2,
    title: 'Server-Side Rendering (SSR)',
    description: 'Dynamic pages generated on the server for every request. Ensures your content is always fresh and indexable by search bots.',
    icon: React.createElement(SeoIcon),
  },
  {
    id: 3,
    title: 'Headless CMS Integration',
    description: 'Empower your marketing team to update content without developer intervention. We integrate with Sanity, Contentful, Strapi, and more.',
    icon: React.createElement(CmsIcon),
  }
];

const mockBlogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'Why Next.js is the Future of Web Development',
    author: 'Jane Doe',
    date: 'October 26, 2023',
    excerpt: 'Next.js offers a powerful combination of SSG and SSR, giving developers unparalleled flexibility and performance. Let\'s dive deep into why it\'s a game-changer.',
    imageUrl: 'https://picsum.photos/seed/blog1/800/600'
  },
  {
    id: 2,
    title: 'Maximizing SEO with a Headless CMS',
    author: 'John Smith',
    date: 'October 22, 2023',
    excerpt: 'A headless CMS decouples your content from your presentation layer, enabling faster load times and more frequent content updates - both are huge SEO wins.',
    imageUrl: 'https://picsum.photos/seed/blog2/800/600'
  },
  {
    id: 3,
    title: 'The Power of Utility-First CSS with Tailwind',
    author: 'Alex Johnson',
    date: 'October 18, 2023',
    excerpt: 'Tailwind CSS allows for rapid UI development without ever leaving your HTML. It results in highly optimized, small CSS files perfect for performance.',
    imageUrl: 'https://picsum.photos/seed/blog3/800/600'
  }
];

// Simulate an API call with a delay
export const getServices = (): Promise<Service[]> => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockServices);
    }, 500); // Short delay for "build-time" data
  });
};

export const getBlogPosts = (): Promise<BlogPost[]> => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockBlogPosts);
    }, 1500); // Longer delay to simulate a real-time request
  });
};