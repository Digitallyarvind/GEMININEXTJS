import React, { useState, useEffect } from 'react';
import { getBlogPosts } from '../services/cmsService';
import { BlogPost } from '../types';
import Spinner from './Spinner';

const BlogPage: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      setLoading(true); // Ensure loading is true on each "navigation"
      try {
        const data = await getBlogPosts();
        setPosts(data);
      } catch (error) {
        console.error("Failed to fetch blog posts:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchPosts();
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">From Our Blog</h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-medium-gray">
            Insights on modern web development. This data is fetched "on request" to simulate SSR, notice the slightly longer load time.
          </p>
        </div>
        {loading ? (
          <Spinner />
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post) => (
              <div key={post.id} className="flex flex-col rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
                <div className="flex-shrink-0">
                  <img className="h-48 w-full object-cover" src={post.imageUrl} alt={post.title} />
                </div>
                <div className="flex-1 bg-light-gray p-6 flex flex-col justify-between">
                  <div className="flex-1">
                    <h3 className="mt-2 text-xl font-semibold text-slate-900">{post.title}</h3>
                    <p className="mt-3 text-base text-medium-gray">{post.excerpt}</p>
                  </div>
                  <div className="mt-6 flex items-center">
                    <div className="text-sm text-medium-gray">
                      <p>{post.author}</p>
                      <p>{post.date}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogPage;
