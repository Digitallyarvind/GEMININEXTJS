import React, { useState, useEffect } from 'react';
import { getServices } from '../services/cmsService';
import { Service } from '../types';
import Spinner from './Spinner';

const ServicesPage: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const data = await getServices();
        setServices(data);
      } catch (error) {
        console.error("Failed to fetch services:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Our Core Strategies</h1>
        <p className="mt-4 max-w-2xl mx-auto text-lg text-medium-gray">
          We utilize modern web architecture to deliver the best results for your business. This is our "static" page content, fetched once.
        </p>
      </div>
      {loading ? (
        <Spinner />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="bg-white rounded-xl shadow-lg p-8 flex flex-col items-center text-center hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1">
              <div className="bg-teal-100 p-4 rounded-full mb-4">
                {service.icon}
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">{service.title}</h2>
              <p className="text-medium-gray">{service.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ServicesPage;
