import React, { useState, useEffect } from 'react';

// --- SVG ICON COMPONENTS ---
const BadgeCheckIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zM12.969 9.28a.75.75 0 00-1.06-1.06l-3.354 3.354a.75.75 0 01-1.06 0L5.53 9.53a.75.75 0 00-1.06 1.06l2.25 2.25a2.25 2.25 0 003.182 0l4.125-4.125z" clipRule="evenodd" /></svg>
);
const ChevronDownIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
);
const StarIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
);

const AffordableSeoPage: React.FC = () => {
    const [formSubmitted, setFormSubmitted] = useState(false);
    const [activeFaq, setActiveFaq] = useState<number | null>(0);
    const [activeTestimonial, setActiveTestimonial] = useState(0);

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setFormSubmitted(true);
        setTimeout(() => setFormSubmitted(false), 5000); // Reset after 5 seconds
    };

    const toggleFaq = (index: number) => {
        setActiveFaq(activeFaq === index ? null : index);
    };
    
    const testimonials = [
        {
            quote: "Our dental clinic now appears first when people search for ‘best dentist near me’. Appointments doubled in 3 months!",
            name: "Dr. Priya Sharma",
            company: "Dental Clinic, Ranchi",
            image: "https://randomuser.me/api/portraits/women/44.jpg",
            metric: "+150% patient leads"
        },
        {
            quote: "We now get daily patient inquiries directly from Google Maps. The visibility on local searches has been a game-changer for our clinic.",
            name: "Anil Kumar",
            company: "Healthcare Services, Bangalore",
            image: "https://randomuser.me/api/portraits/men/32.jpg",
            metric: "+200% inquiries via GMB"
        },
        {
            quote: "The leads for our new real estate project increased by over 45% after ScalifyLabs optimized our online presence. Truly remarkable results.",
            name: "Sunita Reddy",
            company: "Real Estate Developers, Mumbai",
            image: "https://randomuser.me/api/portraits/women/68.jpg",
            metric: "+45% qualified leads"
        },
    ];

    useEffect(() => {
        const timer = setInterval(() => {
            setActiveTestimonial(prev => (prev + 1) % testimonials.length);
        }, 5000);
        return () => clearInterval(timer);
    }, [testimonials.length]);

    const faqs = [
        { q: "What are affordable SEO services and how do they work?", a: "Affordable SEO focuses on high-impact strategies tailored for small to medium businesses. We prioritize local SEO, on-page optimization, and content that delivers measurable results like calls and visits, without the high agency fees." },
        { q: "Are cheap SEO services effective for small businesses?", a: "Many 'cheap' services are ineffective. Our 'affordable' approach is different; it's value-driven. We focus on foundational SEO that builds long-term visibility and provides a clear ROI, making it a smart investment for growth." },
        { q: "What's the difference between City, State and Country level SEO?", a: "City-level targets customers in your immediate area, perfect for local shops. State-level expands your reach to multiple cities, ideal for regional brands. Country-level SEO is for businesses aiming for a national audience, focusing on broad authority and brand presence." },
        { q: "How much do affordable SEO packages cost per month?", a: "Our packages are transparently priced to fit different business sizes, starting from our City-Level plan. Each package is a flat monthly fee with no hidden costs, designed for sustainable growth." },
        { q: "What industries benefit most from affordable SEO?", a: "Any business that relies on local customers sees immense benefits. This includes clinics, restaurants, real estate, home services, coaching centers, and retail stores where online visibility directly translates to foot traffic and leads." },
        { q: "What is AI SEO or Answer Engine Optimization (AEO)?", a: "AEO is the next evolution of SEO. It optimizes your content to be the direct answer for voice searches (like Siri or Alexa) and AI chatbots. This puts your business at the forefront of modern search technology." },
    ];

    const serviceCards = [
        { title: "Local SEO Services", description: "Google Maps & “near me” optimization", points: ["Google My Business optimization", "Local keyword targeting", "Citation building"], benefit: "+200% local visibility"},
        { title: "On-Page SEO Services", description: "Speed, structure, metadata & schema", points: ["Technical SEO audit", "Page speed optimization", "Schema markup"], benefit: "+3s faster site load" },
        { title: "Content Marketing", description: "Blogs, FAQs, landing pages for visibility", points: ["SEO blog writing", "Landing page content", "FAQ optimization"], benefit: "10k new impressions / month" },
        { title: "Google Business Profile (GMB)", description: "Setup, optimization, reviews", points: ["GMB setup & optimization", "Review management", "Post scheduling"], benefit: "Rank in Map Pack"},
        { title: "Link Building & Digital PR", description: "High-quality backlinks & mentions", points: ["Quality link building", "Digital PR campaigns", "Brand mentions"], benefit: "Build Domain Authority" },
        { title: "AI SEO & AEO", description: "Voice & AI search optimization", points: ["Voice search optimization", "Featured snippets", "AI answer optimization"], benefit: "Future-proof your SEO" },
    ];

    return (
        <div className="bg-slate-50 text-slate-700 antialiased leading-relaxed">
            {/* 1. Hero Section */}
            <section className="relative bg-primary text-white overflow-hidden pt-20">
                <div className="absolute inset-0 bg-grid-slate-700/20 [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/30 via-primary to-teal-500/20 opacity-60"></div>
                
                <div className="relative max-w-7xl mx-auto px-6 lg:px-8 z-10 py-20 sm:py-28">
                    <div className="text-center">
                        <span className="inline-flex items-center bg-yellow-400/10 text-accent font-medium text-sm px-4 py-1.5 rounded-full">
                           #1 Affordable SEO Agency in India
                        </span>
                        <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight">
                            Affordable SEO Services That Deliver <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 to-accent">Real Results</span>
                        </h1>
                        <p className="mt-6 text-lg text-slate-300 max-w-3xl mx-auto leading-8">
                            Rank higher on Google, Maps, and AI search — without overspending. Get more calls, visits, and leads with our proven AI-powered SEO strategies.
                        </p>
                        <p className="mt-4 text-lg text-teal-200 max-w-3xl mx-auto font-semibold">
                           Today, SEO isn’t just about ranking — it’s about visibility across search, maps, and AI platforms where customers actually make decisions.
                        </p>
                        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                            <a href="#lead-form" className="group relative inline-flex items-center justify-center w-full sm:w-auto px-8 py-3 font-bold text-primary bg-gradient-to-r from-accent to-yellow-500 rounded-lg shadow-lg transition-transform duration-300 transform hover:-translate-y-1">
                                <span className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity rounded-lg"></span>
                                <span>📊 Get Free SEO Audit Worth ₹5,000</span>
                            </a>
                            <a href="https://wa.me/918788424727" target="_blank" rel="noopener noreferrer" className="inline-block w-full sm:w-auto text-center bg-slate-700/50 border border-slate-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-slate-700 transition-all duration-300">
                               💬 WhatsApp Quick Report
                            </a>
                        </div>
                    </div>
                    {/* Trust Badges & Micro Stats */}
                    <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6 text-center max-w-4xl mx-auto">
                        {['No Long-term Contracts', 'Transparent Reporting', 'Local & National SEO', 'AI-Powered Strategies'].map(text => (
                            <div key={text} className="bg-white/5 backdrop-blur-sm p-4 rounded-lg border border-white/10">
                                <p className="font-semibold text-base text-white">{text}</p>
                            </div>
                        ))}
                    </div>
                     <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 text-center max-w-4xl mx-auto text-base text-slate-300">
                        <span>500+ Happy Clients</span>
                        <span>98% Success Rate</span>
                        <span>24/7 Support</span>
                        <span>Live SEO Dashboard</span>
                    </div>
                </div>
            </section>
            
            {/* 2. Live Performance Snapshot */}
            <section className="py-20 sm:py-24 bg-slate-100">
                <div className="max-w-5xl mx-auto px-6 lg:px-8 text-center">
                    <h2 className="text-3xl font-bold text-slate-900">Real SEO Visibility Data</h2>
                    <p className="text-base text-slate-500">(Updated 5 min ago)</p>
                    <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-6">
                        {[{val: "+285%", label: "Organic Traffic"}, {val: "#1", label: "Google Maps"}, {val: "+150%", label: "Phone Calls"}, {val: "+320%", label: "Website Visits"}].map(metric => (
                            <div key={metric.label} className="bg-white p-6 rounded-xl shadow-lg">
                                <p className="text-4xl font-extrabold text-primary">{metric.val}</p>
                                <p className="mt-2 text-base font-semibold text-slate-600">{metric.label}</p>
                            </div>
                        ))}
                    </div>
                    <p className="mt-8 text-sm text-slate-500">All metrics tracked via GA4 & GMB Insights.</p>
                </div>
            </section>

            {/* 3. What is SEO and Why It Matters */}
            <section className="py-20 sm:py-24">
                <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">What is SEO and Why Does Your Business Need It?</h2>
                        <p className="mt-4 text-lg text-slate-600 leading-8">SEO (Search Engine Optimization) helps your business appear when customers search online. When someone searches “best clinic near me” or “affordable coaching classes”, SEO ensures your business is visible — bringing more calls, visits, and customers.</p>
                        <p className="mt-4 text-lg text-teal-600 font-semibold">Modern SEO isn’t just about ranking on page one — it’s about being visible where your customers are searching, whether on Google, Maps, or AI-powered assistants like ChatGPT or Perplexity.</p>
                    </div>
                    <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
                        {[
                            { title: "📍 Get Found Online", description: "Appear across search, Maps, and voice assistants." },
                            { title: "📞 Generate More Leads", description: "Turn online searches into real calls and walk-ins." },
                            { title: "🚀 Grow Your Business", description: "Build sustainable organic visibility that reduces ad costs." },
                        ].map((item) => (
                            <div key={item.title} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300 text-center">
                                <h3 className="text-xl font-bold text-slate-900">{item.title}</h3>
                                <p className="mt-2 text-slate-600">{item.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 4. Local SEO – The Visibility Goldmine */}
            <section className="bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900 py-20 sm:py-24">
                <div className="max-w-7xl mx-auto px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <h2 className="text-3xl sm:text-4xl font-extrabold">Local SEO is a goldmine. Don't lose customers to competitors.</h2>
                        <p className="mt-4 text-lg text-slate-800 leading-8">Appear in Google Maps and "near me" searches to capture ready-to-buy customers before your competitors do.</p>
                         <a href="#lead-form" className="mt-8 inline-block bg-slate-900 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-slate-800 transition-transform duration-300 transform hover:-translate-y-1">📍 Get My Local SEO Audit Now</a>
                    </div>
                     <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-2xl p-6">
                         <p className="font-semibold text-base flex items-center mb-4"><svg className="w-5 h-5 mr-2 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg> Google Maps Results</p>
                         <div className="space-y-3">
                            <div className="bg-white border-2 border-green-500 rounded-lg p-4 shadow-md">
                                <div className="flex justify-between items-start">
                                    <p className="font-bold text-lg">Your Business</p>
                                    <div className="flex items-center mt-1">
                                        {[...Array(5)].map((_,i) => <StarIcon key={i} className="w-5 h-5 text-yellow-400" />)}
                                        <span className="text-sm font-bold ml-2">(4.9 rating)</span>
                                    </div>
                                </div>
                                <p className="text-base font-semibold text-green-600 mt-1">+25% calls this month</p>
                            </div>
                             <div className="bg-white rounded-lg p-3 border border-slate-200">
                                 <p className="font-bold text-base">Competitor 1 <span className="font-normal text-slate-500 text-sm">- 3.8 stars</span></p>
                             </div>
                             <div className="bg-white rounded-lg p-3 border border-slate-200">
                                 <p className="font-bold text-base">Competitor 2 <span className="font-normal text-slate-500 text-sm">- 4.2 stars</span></p>
                             </div>
                         </div>
                     </div>
                </div>
            </section>

            {/* 5. Comprehensive SEO Services */}
            <section className="py-20 sm:py-24">
                 <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Comprehensive SEO Services We Offer</h2>
                        <p className="mt-4 text-lg text-slate-600 leading-8">From local visibility to national dominance, we deliver full-stack SEO solutions tailored to your business goals.</p>
                    </div>
                    <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {serviceCards.map(service => (
                            <div key={service.title} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300 flex flex-col">
                                <h3 className="text-xl font-bold text-slate-900">{service.title}</h3>
                                <p className="text-slate-600 mt-2">{service.description}</p>
                                <ul className="mt-6 space-y-3 flex-grow">
                                    {service.points.map(point => (
                                        <li key={point} className="flex items-center text-base text-slate-600">
                                           <BadgeCheckIcon className="w-5 h-5 text-teal-500 mr-3 shrink-0"/> {point}
                                        </li>
                                    ))}
                                </ul>
                                <p className="mt-6 text-base font-bold text-teal-700 bg-teal-50 p-3 rounded-lg text-center">{service.benefit}</p>
                            </div>
                        ))}
                    </div>
                 </div>
            </section>
            
            {/* 6. Why Choose ScalifyLabs */}
            <section className="bg-slate-100 py-20 sm:py-24">
                <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Why Businesses Choose ScalifyLabs</h2>
                    <p className="mt-4 text-lg text-slate-600 max-w-3xl mx-auto leading-8">We combine data-driven SEO and AI automation to boost your visibility, not just rankings — helping you show up where it matters most.</p>
                    <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {[
                            {icon: '🤖', title: 'AI-Powered SEO & AEO', text: 'Future-ready for AI search.'},
                            {icon: '🗺️', title: 'City / State / Country SEO', text: 'Scale from local to national.'},
                            {icon: '📈', title: 'Transparent Weekly Reports', text: 'See calls, visits & keywords clearly.'},
                            {icon: '🔗', title: 'Authority & Trust Building', text: 'Backlinks, PR & reviews.'},
                            {icon: '💰', title: 'Affordable Packages', text: 'For growing Indian businesses.'},
                            {icon: '📊', title: 'Proven Results', text: '500+ clients, 98% success rate.'},
                        ].map(item => (
                            <div key={item.title} className="bg-white p-6 rounded-xl shadow-md text-left">
                                <span className="text-3xl">{item.icon}</span>
                                <h3 className="mt-3 text-lg font-bold">{item.title}</h3>
                                <p className="mt-1 text-slate-600">{item.text}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

             {/* 7. Transparent Pricing */}
            <section className="py-20 sm:py-24">
                <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Transparent SEO Packages & Pricing</h2>
                        <p className="mt-4 text-lg text-slate-600 leading-8">Choose the plan that matches your growth goals. No hidden fees, no contracts, 30-day money-back guarantee.</p>
                    </div>
                    <div className="mt-16 grid lg:grid-cols-3 gap-8 items-stretch">
                        {[
                            { title: "City-Level SEO", tag: "Local", price: "9,999", features: ["Maps visibility", "20+ keywords", "Reviews management", "Monthly reports"], popular: false },
                            { title: "State-Level SEO", tag: "Multi-city", price: "19,999", features: ["Everything in City-Level", "4+ blogs/month", "Backlink campaigns", "Google Ads account setup"], popular: true },
                            { title: "Country-Level SEO", tag: "National", price: "49,999", features: ["Everything in State-Level", "Digital PR outreach", "Content strategy", "Dedicated account manager"], popular: false },
                        ].map(plan => (
                             <div key={plan.title} className={`bg-white rounded-2xl shadow-lg p-8 flex flex-col ${plan.popular ? 'border-2 border-accent' : 'border border-slate-200'} relative`}>
                                {plan.popular && <span className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 bg-accent text-primary px-3 py-1 text-sm font-bold rounded-full">Most Popular</span>}
                                <h3 className="text-xl font-bold text-slate-900">{plan.title}</h3>
                                <p className="text-base text-slate-500 mt-1">{plan.tag} Focus</p>
                                <div className="mt-6">
                                    <span className="text-4xl font-extrabold text-slate-900">₹{plan.price}</span>
                                    <span className="text-slate-500">/month</span>
                                </div>
                                <ul className="mt-8 space-y-4 text-slate-600 text-base flex-grow">
                                    {plan.features.map(feat => <li key={feat} className="flex items-start"><BadgeCheckIcon className="w-5 h-5 text-teal-500 mr-3 shrink-0 mt-1"/><span>{feat}</span></li>)}
                                </ul>
                                <a href="#lead-form" className={`mt-8 block w-full text-center font-bold py-3 px-6 rounded-lg transition-all duration-300 ${plan.popular ? 'bg-gradient-to-r from-accent to-yellow-500 text-primary shadow-lg hover:-translate-y-1' : 'bg-primary/5 text-primary hover:bg-primary/10'}`}>📊 Get Started Today</a>
                             </div>
                        ))}
                    </div>
                </div>
            </section>
            
            {/* 8. Real Businesses. Real Growth. */}
            <section className="py-20 sm:py-24 bg-slate-100">
                <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Real Businesses. Real Growth.</h2>
                    </div>
                    <div className="mt-16 relative max-w-3xl mx-auto h-72">
                         {testimonials.map((t, index) => (
                             <div key={index} className={`absolute inset-0 transition-all duration-500 ease-in-out ${index === activeTestimonial ? 'opacity-100 transform scale-100' : 'opacity-0 transform scale-95'}`}>
                                <div className="text-center bg-white p-8 rounded-2xl shadow-xl">
                                    <img src={t.image} alt={t.name} className="w-20 h-20 rounded-full mx-auto shadow-lg" />
                                    <blockquote className="mt-6 text-xl text-slate-800 font-medium italic">“{t.quote}”</blockquote>
                                    <cite className="mt-4 block font-bold text-slate-900 not-italic">{t.name}, <span className="font-normal text-slate-500">{t.company}</span></cite>
                                    <div className="mt-4 inline-block bg-teal-100 text-teal-800 font-bold px-4 py-2 rounded-full">{t.metric}</div>
                                </div>
                            </div>
                         ))}
                    </div>
                    <div className="flex justify-center space-x-3 mt-4">
                        {testimonials.map((_, index) => (
                           <button key={index} onClick={() => setActiveTestimonial(index)} aria-label={`Go to testimonial ${index + 1}`} className={`w-3 h-3 rounded-full transition-colors duration-300 ${index === activeTestimonial ? 'bg-primary' : 'bg-slate-300 hover:bg-slate-400'}`}></button>
                        ))}
                    </div>
                </div>
            </section>
            
            {/* 9. Industries We Serve */}
             <section className="py-20 sm:py-24">
                <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Industries We Serve with SEO Excellence</h2>
                        <p className="mt-4 text-lg text-slate-600 leading-8">Our SEO services are built for visibility-led growth — if your business runs on leads, we can help.</p>
                    </div>
                    <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {[
                            {icon: '🏠', title: 'Real Estate', queries: ['"flats for sale"', '"property near me"']},
                            {icon: '⚕️', title: 'Healthcare & Clinics', queries: ['"dentist near me"', '"best clinic"']},
                            {icon: '🎓', title: 'Coaching & Education', queries: ['"coaching classes"', '"best university"']},
                            {icon: '🛍️', title: 'Retail & Restaurants', queries: ['"restaurant near me"', '"shopping mall"']},
                            {icon: '🛠️', title: 'Home Services', queries: ['"plumber near me"', '"electrician services"']},
                            {icon: '💼', title: 'Professional Services', queries: ['"lawyer near me"', '"ca services"']},
                            {icon: '🚗', title: 'Automotive', queries: ['"car dealer"', '"auto service"']},
                            {icon: '🧘', title: 'Wellness & Fitness', queries: ['"gym near me"', '"yoga classes"']},
                        ].map(industry => (
                            <div key={industry.title} className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
                                <span className="text-4xl">{industry.icon}</span>
                                <h3 className="mt-4 text-lg font-bold">{industry.title}</h3>
                                <div className="mt-2 space-x-2">
                                    {industry.queries.map(q => <span key={q} className="inline-block bg-slate-100 text-slate-600 text-sm px-2 py-1 rounded-full">{q}</span>)}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

             {/* 10. Lead Form Section */}
            <section id="lead-form" className="bg-gradient-to-br from-[#001F3F] to-[#0c2646] py-20 sm:py-24">
                <div className="max-w-5xl mx-auto px-6 lg:px-8">
                    <div className="text-center text-white">
                        <h2 className="text-3xl sm:text-4xl font-extrabold">Get Your Free SEO Audit & Visibility Report</h2>
                        <p className="mt-4 text-lg text-slate-300 leading-8">Discover exactly how to boost your visibility and get more customers — worth ₹5,000, completely free.</p>
                    </div>
                    <div className="mt-12 grid lg:grid-cols-2 gap-12 items-center">
                        <div className="text-white">
                             <div className="space-y-6">
                                <div className="flex items-start">
                                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-500 text-primary flex items-center justify-center font-bold">1</div>
                                    <div className="ml-4">
                                        <h3 className="font-bold text-base">Confirm Details</h3>
                                        <p className="text-slate-300">Fill the form and we'll confirm on WhatsApp.</p>
                                    </div>
                                </div>
                                 <div className="flex items-start">
                                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-500 text-primary flex items-center justify-center font-bold">2</div>
                                    <div className="ml-4">
                                        <h3 className="font-bold text-base">Receive Report in 24 Hours</h3>
                                        <p className="text-slate-300">Get a detailed audit of your online visibility.</p>
                                    </div>
                                </div>
                                 <div className="flex items-start">
                                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-500 text-primary flex items-center justify-center font-bold">3</div>
                                    <div className="ml-4">
                                        <h3 className="font-bold text-base">Get a 15-Min Strategy Call</h3>
                                        <p className="text-slate-300">Discuss a 90-day action plan with our experts.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white p-8 rounded-2xl shadow-2xl">
                            <form onSubmit={handleFormSubmit} className="space-y-4">
                                <div className="grid sm:grid-cols-2 gap-4">
                                    <input type="text" placeholder="Full Name" required className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary text-base"/>
                                    <input type="email" placeholder="Email" required className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary text-base"/>
                                    <input type="text" placeholder="City / Location" required className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary text-base"/>
                                    <input type="tel" placeholder="WhatsApp Number" required className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary text-base"/>
                                </div>
                                <select className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary bg-white text-slate-500 text-base" defaultValue="">
                                    <option value="" disabled>Business Type</option>
                                    <option>Healthcare</option>
                                    <option>Education</option>
                                    <option>Real Estate</option>
                                    <option>Other</option>
                                </select>
                                <select className="block w-full px-4 py-3 border border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary bg-white text-slate-500 text-base" defaultValue="">
                                    <option value="" disabled>Package Interest</option>
                                    <option>City-Level SEO</option>
                                    <option>State-Level SEO</option>
                                    <option>Country-Level SEO</option>
                                </select>
                                <div className="bg-blue-50 text-blue-800 p-3 rounded-md text-base">
                                    <span className="font-bold">What you'll get:</span> SEO visibility audit, keyword gaps, competitor research, and 90-day action plan.
                                </div>
                                <button type="submit" className="w-full bg-gradient-to-r from-accent to-yellow-500 text-primary font-bold py-3 px-6 rounded-lg shadow-lg hover:-translate-y-1 transition-transform duration-300 text-lg">
                                   🚀 Get My Free SEO Audit Report (Worth ₹5,000)
                                </button>
                            </form>
                             {formSubmitted && (
                                <div aria-live="polite" className="mt-4 text-center text-green-800 bg-green-100 p-3 rounded-md font-semibold">
                                    Thanks! Your audit will be sent within 24 hours.
                                </div>
                            )}
                             <p className="mt-4 text-center text-sm text-slate-500">🛡️ No spam. No sales pressure. 100% privacy.</p>
                        </div>
                    </div>
                </div>
            </section>
            
            {/* 11. FAQs */}
            <section className="py-20 sm:py-24">
                <div className="max-w-4xl mx-auto px-6 lg:px-8">
                    <div className="text-center">
                         <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Frequently Asked Questions About SEO</h2>
                    </div>
                    <div className="mt-12 space-y-4">
                        {faqs.map((faq, index) => (
                             <div key={index} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                                <button
                                    onClick={() => toggleFaq(index)}
                                    aria-expanded={activeFaq === index}
                                    className="w-full flex justify-between items-center p-5 text-left font-bold text-lg text-slate-800 hover:bg-slate-50 transition-colors"
                                >
                                    <span>{faq.q}</span>
                                    <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 shrink-0 ${activeFaq === index ? 'rotate-180' : ''}`} />
                                </button>
                                <div className={`transition-all duration-300 ease-in-out ${activeFaq === index ? 'max-h-60 opacity-100' : 'max-h-0 opacity-0'}`}>
                                    <p className="px-5 pb-5 text-slate-600 leading-relaxed">{faq.a}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

             {/* 12. Final CTA Banner */}
            <section className="bg-primary">
                <div className="max-w-7xl mx-auto text-center py-20 px-6 lg:px-8">
                     <h2 className="text-3xl sm:text-4xl font-extrabold text-white">Ready to Grow Your Visibility Across Google & AI Search?</h2>
                     <p className="mt-4 text-xl text-teal-300 font-medium">Stop losing leads to competitors who appear before you.</p>
                     <div className="mt-8 flex flex-wrap justify-center gap-4">
                        <a href="#lead-form" className="inline-block bg-gradient-to-r from-accent to-yellow-500 text-primary font-bold py-3 px-8 rounded-lg shadow-lg hover:-translate-y-1 transition-transform duration-300">
                           📊 Get Free SEO Audit
                        </a>
                        <a href="https://wa.me/918788424727" target="_blank" rel="noopener noreferrer" className="inline-flex items-center bg-green-500 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-green-600 transition-colors duration-300">
                            <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.886-.001 2.269.654 4.525 1.903 6.44l-1.199 4.382 4.555-1.19z" /></svg>
                            💬 WhatsApp Us Now
                        </a>
                     </div>
                     <div className="mt-8 text-base text-slate-400 flex justify-center items-center flex-wrap gap-x-6 gap-y-2">
                        <span>✅ No long-term contracts</span>
                        <span>✅ 30-day money-back guarantee</span>
                        <span>✅ Transparent reports</span>
                     </div>
                </div>
            </section>
        </div>
    );
};

export default AffordableSeoPage;
