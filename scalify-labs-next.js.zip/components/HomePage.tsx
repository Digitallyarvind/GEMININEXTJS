import React from 'react';

const HomePage: React.FC = () => {
  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight">
            Build Your <span className="text-primary">Modern Web Presence</span>
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-medium-gray">
            Leveraging the best of React, Next.js, and headless architecture to create blazingly fast, SEO-friendly, and scalable websites.
          </p>
          <div className="mt-8">
            <a
              href="#"
              onClick={e => e.preventDefault()}
              className="inline-block bg-primary text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-primary-dark transition-transform transform hover:-translate-y-1"
            >
              Get Started
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-800">The Best Rendering Strategy, Per Page</h2>
            <p className="mt-2 text-md text-medium-gray">Flexibility and performance combined.</p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-slate-900">Static Site Generation (SSG)</h3>
              <p className="mt-2 text-medium-gray">
                For pages like this one! Pre-rendered at build time for maximum speed. Perfect for landing pages, blogs, and marketing sites.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-slate-900">Server-Side Rendering (SSR)</h3>
              <p className="mt-2 text-medium-gray">
                Content is generated on each request, ensuring data is always up-to-date. Ideal for e-commerce, dashboards, and personalized content.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-slate-900">Optimized for Vercel</h3>
              <p className="mt-2 text-medium-gray">
                As creators of Next.js, Vercel provides a seamless, zero-configuration deployment experience with a global CDN for unmatched performance.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
