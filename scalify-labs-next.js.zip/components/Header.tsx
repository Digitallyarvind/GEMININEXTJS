import React, { useState, useEffect } from 'react';
import { Page } from '../types';

interface HeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

interface NavItem {
  name: Page;
  href: string;
  type: 'link' | 'dropdown';
  subItems?: { name: string; href: string }[];
}

const navItems: NavItem[] = [
  { name: 'Home', href: '/', type: 'link' },
  {
    name: 'Services',
    href: '#',
    type: 'dropdown',
    subItems: [
      { name: 'SEO & AEO Services', href: '/services/seo' },
      { name: 'Paid Ads (Google & Meta)', href: '/services/paid-ads' },
      { name: 'Website Design & Development', href: '/services/web-design' },
      { name: 'Social Media Marketing', href: '/services/social-media' },
      { name: 'WhatsApp Marketing', href: '/services/whatsapp-marketing' },
      { name: 'RCS Marketing', href: '/services/rcs-marketing' },
      { name: 'Marketing & CRM Automation', href: '/services/marketing-automation' },
    ],
  },
  {
    name: 'AI Solutions',
    href: '#',
    type: 'dropdown',
    subItems: [
      { name: 'AI Calling Agent', href: '/ai/ai-calling-agent' },
      { name: 'AI WhatsApp Bot', href: '/ai/ai-whatsapp-bot' },
      { name: 'AI Clone for Content Creation', href: '/ai/ai-clone' },
      { name: 'Blogging Automation', href: '/ai/blogging-automation' },
    ],
  },
  {
    name: 'Industry',
    href: '#',
    type: 'dropdown',
    subItems: [
      { name: 'Education', href: '/industry/education' },
      { name: 'Healthcare', href: '/industry/healthcare' },
      { name: 'Real Estate', href: '/industry/real-estate' },
    ],
  },
    {
    name: 'Training',
    href: '#',
    type: 'dropdown',
    subItems: [
      { name: 'OneManMarketer', href: '/training/onemanmarketer' },
      { name: 'Career Mentoring', href: '/training/career-mentoring' },
      { name: 'Workshop', href: '/training/workshop' },
    ],
  },
  { name: 'Blog', href: '/blog', type: 'link' },
];

const ChevronDownIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
);


const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? 'hidden' : 'auto';
    return () => { document.body.style.overflow = 'auto' };
  }, [isMenuOpen]);
  
  const handleNav = (page: Page) => {
    setCurrentPage(page);
    setIsMenuOpen(false);
  }

  return (
    <header className="bg-primary/90 backdrop-blur-md shadow-lg text-light-text fixed top-0 left-0 right-0 z-50 h-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="#" onClick={(e) => { e.preventDefault(); handleNav('Home'); }} className="text-2xl font-bold">
              Scalify Labs
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              item.type === 'dropdown' ? (
                <div key={item.name} className="relative group">
                   <button onClick={(e) => { e.preventDefault(); handleNav(item.name); }} className="px-3 py-2 rounded-md text-sm font-medium hover:text-teal flex items-center gap-1 transition-colors">
                    {item.name} <ChevronDownIcon />
                  </button>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-white rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 ease-in-out transform group-hover:translate-y-0 translate-y-2">
                     <div className="p-2">
                        {item.subItems?.map((subItem) => (
                            <a 
                                key={subItem.name} 
                                href="#" 
                                onClick={(e) => { 
                                    e.preventDefault(); 
                                    if (subItem.name === 'SEO & AEO Services') {
                                        handleNav('Services/SEO');
                                    } else {
                                        handleNav(item.name);
                                    }
                                }} 
                                className="block px-4 py-2 text-sm text-dark-text rounded-md hover:bg-light-gray hover:text-primary transition-colors"
                            >
                                {subItem.name}
                            </a>
                        ))}
                     </div>
                  </div>
                </div>
              ) : (
                <a key={item.name} href="#" onClick={(e) => { e.preventDefault(); handleNav(item.name); }} className="px-3 py-2 rounded-md text-sm font-medium hover:text-teal transition-colors">
                  {item.name}
                </a>
              )
            ))}
             <a href="#" onClick={(e) => { e.preventDefault(); handleNav('Contact'); }} className="px-3 py-2 rounded-md text-sm font-medium hover:text-teal transition-colors">Contact Us</a>
             <a href="#" onClick={(e) => { e.preventDefault(); handleNav('Contact'); }} className="ml-4 px-5 py-2.5 rounded-md text-sm font-bold bg-accent text-primary hover:bg-gradient-to-r from-accent to-teal transition-all duration-300">
                Book Free Consultation
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} aria-controls="mobile-menu" aria-expanded={isMenuOpen} className="inline-flex items-center justify-center p-2 rounded-md text-light-text hover:bg-white/10 focus:outline-none">
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
              ) : (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
       {isMenuOpen && <MobileMenu navItems={navItems} handleNav={handleNav} />}
    </header>
  );
};

// Mobile Menu Sub-component
const MobileMenu: React.FC<{ navItems: NavItem[], handleNav: (page: Page) => void }> = ({ navItems, handleNav }) => {
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);

    const toggleAccordion = (name: string) => {
        setOpenAccordion(openAccordion === name ? null : name);
    }

    return (
        <div id="mobile-menu" className="md:hidden fixed inset-0 top-20 bg-primary z-40 p-4 flex flex-col">
            <nav className="flex-grow overflow-y-auto">
                {navItems.map(item => (
                     item.type === 'dropdown' ? (
                        <div key={item.name} className="py-2 border-b border-white/10">
                            <button onClick={() => toggleAccordion(item.name)} className="w-full flex justify-between items-center text-lg font-semibold py-2">
                                {item.name}
                                <span className={`transform transition-transform duration-300 ${openAccordion === item.name ? 'rotate-180' : ''}`}>
                                    <ChevronDownIcon />
                                </span>
                            </button>
                             <div className={`overflow-hidden transition-all duration-300 ease-in-out ${openAccordion === item.name ? 'max-h-96' : 'max-h-0'}`}>
                                <div className="pl-4 pt-2 pb-1 space-y-1">
                                    {item.subItems?.map(subItem => (
                                        <a 
                                            key={subItem.name} 
                                            href="#" 
                                            onClick={(e) => { 
                                                e.preventDefault(); 
                                                if (subItem.name === 'SEO & AEO Services') {
                                                    handleNav('Services/SEO');
                                                } else {
                                                    handleNav(item.name);
                                                }
                                            }} 
                                            className="block py-2 text-base text-white/80 hover:text-white"
                                        >
                                            {subItem.name}
                                        </a>
                                    ))}
                                </div>
                            </div>
                        </div>
                     ) : (
                         <a key={item.name} href="#" onClick={(e) => { e.preventDefault(); handleNav(item.name); }} className="block text-lg font-semibold py-3 border-b border-white/10">
                            {item.name}
                        </a>
                     )
                ))}
                 <a href="#" onClick={(e) => { e.preventDefault(); handleNav('Contact'); }} className="block text-lg font-semibold py-3 border-b border-white/10">Contact Us</a>
            </nav>
            <div className="mt-4">
                 <a href="#" onClick={(e) => { e.preventDefault(); handleNav('Contact'); }} className="w-full block text-center px-5 py-3 rounded-md text-base font-bold bg-accent text-primary hover:bg-gradient-to-r from-accent to-teal transition-all duration-300">
                    Book Free Consultation
                </a>
            </div>
        </div>
    );
};


export default Header;